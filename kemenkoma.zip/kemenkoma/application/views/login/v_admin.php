<html>
<head>
	<title></title>
</head>
<body>
	<div class="container">
		<div class="row">
			<table class="table table-bordered table-striped">
				<thead>
					<tr>
						<th rowspan="2">No</th>
						<th rowspan="2">Isu / Program</th>
						<th colspan="3">Penanggung Jawab</th>
						<th rowspan="2">Pencapaian yang Lalu</th>
						<th rowspan="2">Pencapaian Saat Ini</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>Kementrian A</td>
						<td>Kementrian B</td>
						<td>Kementrian C</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</body>
</html>