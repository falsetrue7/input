<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title;?></title>
	<?php $this->load->view('template/inc');?>
	<script>
		$( function() {
			$( "#in_date" ).datepicker({dateFormat: 'yy-mm-dd'});
		} );
	</script>
</head>
<body>
<?php $this->load->view('template/nav');?>
	<div class="container padd">
		<div class="row">
			<div class="panel panel-default">
				<div class="panel-body">
					<form class="form-horizontal" action="<?php echo site_url('input/data_input');?>" method="POST">
					<fieldset>

					<!-- Form Name -->
					<legend>Input Pencapaian</legend>

					<!-- Text input-->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="in_date">Tanggal Rapat</label>  
					  <div class="col-md-4">
					  <input id="in_date" name="in_date" type="text" placeholder="" class="form-control input-md" required="">
					    
					  </div>
					</div>

					<!-- Text input-->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="in_issue">Isu / Program</label>  
					  <div class="col-md-4">
					  <input id="in_issue" name="in_issue" type="text" placeholder="" class="form-control input-md" required="">
					    
					  </div>
					</div>

					<!-- Text input-->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="in_pic">Penanggung Jawab</label>  
					  <div class="col-md-4">
					  <input id="in_pic" name="in_pic" type="text" placeholder="" class="form-control input-md" required="">
					    
					  </div>
					</div>

					<div class="add_achieve" id="entry1">
					<!-- Textarea -->
						<div class="form-group" >
						  <label class="col-md-4 control-label label_achieve" for="in_achievement">Pencapaian</label>
						  <div class="col-md-4" id="achievement">                     
						    <textarea class="form-control input_achieve" id="in_achievement" name="in_achievement[]" style="width: 100%; height: 300px;"></textarea>
						  </div>
						</div>
					</div>

					<div class="form-group">
						<div class="col-md-6">
							<center><button id="add_rows" class="btn btn-success">Tambah Pencapaian</button></center>
						</div>
						<div class="col-md-6">
							<center><button id="del_rows" class="btn btn-danger">Kurangi Pencapaian</button></center>
						</div>
					</div>

					<!--Submit-->
					<div class="form-group">
					  <div class="col-md-12">                     
					    <center><input type="submit" name="submit" value="Submit" class="btn btn-info"></center>
					  </div>
					  <div class="col-md-12">                     
					    <center><input type="reset" name="submit" value="Reset" class="btn btn-danger"></center>
					  </div>
					</div>

					</fieldset>
					</form>

				</div>
			</div>
		</div>
	</div>
	<script type="text/javascript">
		/*$(document).ready(function(){
		var counterb = 1;
		$("#add_rows").click(function(){
		$("#achievement").append('<textarea class="form-control"' + ' id="in_achievement'+ counterb +'" name="in_achievement[]"' + 'style="width: 100%; height: 300px;"></textarea>'+'<br/>');
		counterb++;
		  });
		});*/
	</script>
</body>
</html>