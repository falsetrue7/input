<html>
<head>
	<title><?php echo $title;?></title>
	<?php $this->load->view('template/inc');?>
</head>
<body>
<?php $this->load->view('template/nav_usr');?>
	<div class="container padd">
		<div class="row">

			<table class="table table-bordered table-striped">
				<thead>
					<tr>
						<center><th rowspan="2">No</th>
						<th rowspan="2">Isu / Program</th>
						<th colspan="3">Penanggung Jawab</th>
						<th rowspan="2">Pencapaian yang Lalu</th>
						<th rowspan="2">Pencapaian Saat Ini</th>
						</center>
					</tr>
					<tr>
						<td>Kementrian A</td>
						<td>Kementrian B</td>
						<td>Kementrian C</td>
					</tr>
				</thead>
				<tbody>
					
				</tbody>
			</table>
		</div>
	</div>
</body>
</html>