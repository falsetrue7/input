<!--CSS-->
<link rel="stylesheet" type="text/css" href="<?php echo base_url('asset/css/jquery-ui.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('asset/css/bootstrap.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('asset/css/bootstrap.min.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('asset/css/bootstrap-theme.css');?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('asset/css/bootstrap-theme.min.css');?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('asset/css/style.css');?>">

<!--JQuery-->
<script type="text/javascript" src="<?php echo base_url('asset/jquery/jquery.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('asset/jquery/jquery-ui.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('asset/jquery/daterangepicker.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('asset/jquery/moment.js');?>"></script>

<!--Javascript-->
<script type="text/javascript" src="<?php echo base_url('asset/js/bootstrap.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('asset/js/npm.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('asset/js/clone-form.js');?>"></script>

<!--ICO-->