<html>
<head>
	<title><?php echo $title;?></title>
	<?php $this->load->view('template/inc');?>
</head>
<body style="padding-top: 10%;">
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-md-offset-3">
				<div class="panel panel-default">
					<div class="panel-heading">
						<center><img src="<?php echo base_url('asset/img/ico/logo-front.png');?>" style="width: 100%;"></center>
					</div>
					<div class="panel-body">
						<form class="form-horizontal" role="form" action="<?php echo site_url('auth/check');?>" method="POST">
							<div class="form-group">
								<label class="col-md-4 control-label" for="textinput">Masukkan Username</label>
								<div class="col-md-5">
									<input type="text" name="u_id" id="u_id" class="form-control input-md" placeholder="Masukkan Username" required/>
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-4 control-label" for="password">Masukkan Password</label>
								<div class="col-md-5">
									<input type="password" name="u_pass" id="u_pass" class="form-control input-md" placeholder="Input Password" required/>
								</div>
							</div>
							<div class="form-group">
								<div class="col-md-12">
									<center><input type="submit" value="Log In" class="btn btn-info"></center>
								</div>
							</div>
						</form>
						<div style="border-top:1px #9c9c9c; background-color:grey;">
							<div class="col-md-5">
								<center><a href="#">Forgot Password</a></center>
							</div>
							<div class="col-md-2">
								<center>|</center>
							</div>
							<div class="col-md-5">
								<center><a href="<?php echo site_url('auth/register')?>">Daftar</a></center>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>