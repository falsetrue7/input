<?php defined('BASEPATH') OR exit('No direct script access allowed');
	Class Auth extends CI_Controller{
		public function __construct(){
			parent::__construct();
			$this->load->model('m_login');
		}
		public function index(){
			$data['title'] = "Login";
			$this->load->view('v_login',$data);
		}
		public function check(){
			$uname	= $this->input->post('u_id');
			$pass	= $this->input->post('u_pass');

			$this->form_validation->set_rules('u_id','User ID','required');
			$this->form_validation->set_rules('u_pass','User Password','trim|required');

			$data = array(
				'name_user' => $uname,
				'pass_user' => sha1($pass)
				);

			if($this->form_validation->run() == FALSE){
				$this->load->view('v_login');
			}else{
				$usr = $this->m_login->login($data);
				if($usr->num_rows() == 1){
					foreach($usr->result() as $sess){
						$sess_data['logged_in'] = "Logged In";
						$sess_data['id'] = $sess->id_user;
						$sess_data['uname'] = $sess->name_user;
						$sess_data['level'] = $sess->level_user;
						$this->session->set_userdata($sess_data);
					}
					// Use for Check Error
					//echo $this->session->userdata();

					if($this->session->userdata('level') == '1'){
						redirect('admin/admin');
					}elseif ($this->session->userdata('level') == '2') {
						redirect('user/user');
					}
				}else{
					echo "<script>alert('Username atau Password Salah');</script>";
				}
			}
		}
		public function logout(){
			$this->session->unset_userdata('logged_in',$sess_data);
			$this->session->sess_destroy();
			redirect(base_url());
		}

		public function register(){
			$title['title'] = "Register";
			$usrname = $this->input->post('reg_u_id');
			$usrpass = $this->input->post('reg_u_pass');
			$usrlevel = $this->input->post('level');

			$data = array(
				'name_user' => $usrname,
				'pass_user' => sha1($usrpass),
				'level_user' => $usrlevel
				);

			$this->form_validation->set_rules('reg_u_id','Registrasi User ID','required');
			$this->form_validation->set_rules('reg_u_pass','Registrasi User Pass','trim|required');
			$this->form_validation->set_rules('level','Registrasi User Level','required');

			if($this->form_validation->run() == FALSE){
				$this->load->view('login/v_register',$title);
			}else{
				$this->m_login->register($data);
				echo "<script>alert('Sukses Registrasi');</script>";
				redirect('auth/index');
			}
		}
	}
