<?php
	Class Admin extends CI_Controller{
		public function __construct(){
			parent::__construct();
			$this->load->model('m_input');
		}
		public function index(){
			$data['title'] = "Admin Dashboard";
			$this->load->view('dashboard/v_admin',$data);
		}

		public function view_data(){
			
		}
	}
