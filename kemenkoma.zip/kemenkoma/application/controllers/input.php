<?php defined('BASEPATH') OR exit('No direct script access allowed');
	Class Input extends CI_Controller{
		public function __construct(){
			parent::__construct();
			$this->load->model('m_input');
		}

		public function index(){
			$data['title'] = "Input Data";
			$this->load->view('data/v_input',$data);
		}

		public function data_input(){
			/***************************
			*		FOR INPUT 		   *
			****************************/
			$date = $this->input->post('in_date');
			$issue = $this->input->post('in_issue');
			$pj = $this->input->post('in_pic');
			$achieve = $this->input->post('in_achievement');
			
			$this->form_validation->set_rules('in_date','Input Date','required');
			$this->form_validation->set_rules('in_issue','Input Issue','required');
			$this->form_validation->set_rules('in_pic','Input PJ','required');

			if($this->form_validation->run() == FALSE){
				redirect('input');
			}else{
				/***************************
				*		FOR DEBUGGING	   *
				****************************/
				//echo $date." ".$issue." ".$pj;
				
				/***************************
				*		FOR INSERT DB	   *
				****************************/
				$tb_issue = array(
					'name_issue' => $issue,
					'date_issue' => $date,
					'pj_issue'   => $pj
					);
				$this->m_input->set_data($tb_issue);
				foreach ($achieve as $acv => $a) {
					/***************************
					*		FOR DEBUGGING	   *
					****************************/
					
					/*$tb_achieve = array(
						'achieve_text' => $a,
						'id' => "LAST_INSERT_ID()"
						);
					$this->m_input->set_data2($tb_achieve);*/
				}
				echo $a;
				//redirect('input');
			}
		}
	}
?>