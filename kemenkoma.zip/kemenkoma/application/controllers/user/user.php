<?php
	Class User extends CI_Controller{
		public function __construct(){
			parent::__construct();
			
		}
		public function index(){
			$data['title'] = "User Dashboard";
			$this->load->view('dashboard/v_user',$data);
		}

		public function export(){
			
		}
	}
