<?php defined('BASEPATH') OR exit('No direct script access allowed');
	Class M_login extends CI_Model{
		public function __construct(){
			parent::__construct();
		}
		public function login($data){
			$query = $this->db->get_where('user',$data);
			return $query;
		}
		public function register($data){
			return $this->db->insert('user',$data);
		}
	}
?>