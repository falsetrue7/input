<?php defined('BASEPATH') OR exit('No direct script access allowed');
	Class M_input extends CI_Model{
		public function __construct(){
			parent::__construct();
		}
		public function set_data($data1){
			return $this->db->insert('issue',$data1);
		}
		public function set_data2($data){
			return $this->db->insert('achievement',$data);
		}
		public function get_data(){

		}
	}